<?php

/**
 * Admin Configuration
 * Secure admin credentials with encrypted password
 * DO NOT modify this file unless you know what you're doing
 */

class AdminConfig {
    // Admin credentials (encrypted)
    private static $adminCredentials = [
        'username' => 'AdminCEO',
        'password_hash' => '$2y$12$J8vXQ2Kn4mP9rL7wE3tZ5uyB8hF6dN2sA1cV9xW4qR8pL3mK7jH5iG', // CEONO1AERORATHAA
        'role' => 'super_admin',
        'permissions' => [
            'all_employees_access',
            'all_files_access', 
            'system_admin',
            'user_management',
            'system_settings'
        ],
        'created_at' => '2024-01-01 00:00:00'
    ];

    /**
     * Verify admin credentials
     */
    public static function verifyAdmin($username, $password) {
        if ($username !== self::$adminCredentials['username']) {
            return false;
        }

        return password_verify($password, self::$adminCredentials['password_hash']);
    }

    /**
     * Get admin user data (without sensitive info)
     */
    public static function getAdminData() {
        return [
            'id' => 'admin_ceo_001',
            'username' => self::$adminCredentials['username'],
            'email' => 'admin@company.com',
            'role' => self::$adminCredentials['role'],
            'permissions' => self::$adminCredentials['permissions'],
            'is_admin' => true,
            'created_at' => self::$adminCredentials['created_at']
        ];
    }

    /**
     * Check if user has admin permissions
     */
    public static function isAdmin($userData) {
        return isset($userData['is_admin']) && $userData['is_admin'] === true;
    }

    /**
     * Check specific admin permission
     */
    public static function hasPermission($userData, $permission) {
        if (!self::isAdmin($userData)) {
            return false;
        }

        return in_array($permission, $userData['permissions'] ?? []);
    }

    /**
     * Generate new password hash (for development/testing only)
     * This method should be removed in production
     */
    public static function generatePasswordHash($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
}

// Helper function to check admin access
function requireAdminAccess($userData) {
    if (!AdminConfig::isAdmin($userData)) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Admin access required'
        ]);
        exit;
    }
}
