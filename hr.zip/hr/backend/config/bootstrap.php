<?php

/**
 * Bootstrap script for HR Management System
 * Loads environment variables and initializes reusable Guzzle client
 * for Supabase REST & Storage endpoints
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;
use GuzzleHttp\Client;

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Validate required environment variables
$requiredVars = ['SUPABASE_URL', 'SUPABASE_ANON_KEY'];
foreach ($requiredVars as $var) {
    if (empty($_ENV[$var])) {
        throw new Exception("Required environment variable {$var} is not set");
    }
}

// Initialize Supabase REST client
$supabaseRestClient = new Client([
    'base_uri' => $_ENV['SUPABASE_URL'] . '/rest/v1/',
    'headers' => [
        'apikey' => $_ENV['SUPABASE_ANON_KEY'],
        'Authorization' => 'Bearer ' . $_ENV['SUPABASE_ANON_KEY'],
        'Content-Type' => 'application/json',
        'Prefer' => 'return=representation'
    ],
    'timeout' => 10.0,
]);

// Initialize Supabase Storage client
$supabaseStorageClient = new Client([
    'base_uri' => $_ENV['SUPABASE_URL'] . '/storage/v1/',
    'headers' => [
        'apikey' => $_ENV['SUPABASE_ANON_KEY'],
        'Authorization' => 'Bearer ' . $_ENV['SUPABASE_ANON_KEY'],
    ],
    'timeout' => 30.0, // Longer timeout for file operations
]);

// Initialize Auth client for Supabase Auth operations
$supabaseAuthClient = new Client([
    'base_uri' => $_ENV['SUPABASE_URL'] . '/auth/v1/',
    'headers' => [
        'apikey' => $_ENV['SUPABASE_ANON_KEY'],
        'Content-Type' => 'application/json',
    ],
    'timeout' => 10.0,
]);

// Global configuration array
$config = [
    'supabase' => [
        'url' => $_ENV['SUPABASE_URL'],
        'anon_key' => $_ENV['SUPABASE_ANON_KEY'],
        'service_role_key' => $_ENV['SUPABASE_SERVICE_ROLE_KEY'] ?? null,
    ],
    'jwt' => [
        'secret' => $_ENV['JWT_SECRET'] ?? 'default_secret_change_in_production',
        'algorithm' => $_ENV['JWT_ALGORITHM'] ?? 'HS256',
    ],
    'app' => [
        'env' => $_ENV['APP_ENV'] ?? 'development',
        'debug' => filter_var($_ENV['APP_DEBUG'] ?? 'false', FILTER_VALIDATE_BOOLEAN),
        'url' => $_ENV['APP_URL'] ?? 'http://localhost:8000',
    ],
];

// Make clients and config globally available
$GLOBALS['supabase_rest_client'] = $supabaseRestClient;
$GLOBALS['supabase_storage_client'] = $supabaseStorageClient;
$GLOBALS['supabase_auth_client'] = $supabaseAuthClient;
$GLOBALS['config'] = $config;

// Initialize error handling
require_once __DIR__ . '/error_handler.php';

// Helper function to get Supabase REST client
function getSupabaseRestClient(): Client
{
    return $GLOBALS['supabase_rest_client'];
}

// Helper function to get Supabase Storage client
function getSupabaseStorageClient(): Client
{
    return $GLOBALS['supabase_storage_client'];
}

// Helper function to get Supabase Auth client
function getSupabaseAuthClient(): Client
{
    return $GLOBALS['supabase_auth_client'];
}

// Helper function to get configuration
function getConfig(string $key = null)
{
    $config = $GLOBALS['config'];
    
    if ($key === null) {
        return $config;
    }
    
    $keys = explode('.', $key);
    $value = $config;
    
    foreach ($keys as $k) {
        if (!isset($value[$k])) {
            return null;
        }
        $value = $value[$k];
    }
    
    return $value;
}
