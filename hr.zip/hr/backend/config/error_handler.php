<?php

/**
 * Global Error Handler
 * Converts exceptions to consistent JSON responses and logs stack traces
 */

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/../utils/auth.php';

/**
 * Custom exception handler that converts all exceptions to JSON responses
 * 
 * @param Throwable $exception
 */
function globalExceptionHandler(Throwable $exception): void
{
    $config = getConfig();
    $isDebug = $config['app']['debug'] ?? false;
    
    // Get the HTTP status code from the exception if available
    $statusCode = method_exists($exception, 'getCode') && $exception->getCode() >= 100 && $exception->getCode() < 600 
        ? $exception->getCode() 
        : 500;
    
    // If no valid HTTP status code, default to 500
    if ($statusCode < 100 || $statusCode >= 600) {
        $statusCode = 500;
    }
    
    // Log the full error details
    logError($exception);
    
    // Prepare error response
    $errorResponse = [
        'success' => false,
        'error' => $exception->getMessage() ?: 'An unexpected error occurred'
    ];
    
    // In debug mode, include additional details
    if ($isDebug) {
        $errorResponse['debug'] = [
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString(),
            'type' => get_class($exception)
        ];
    }
    
    // Ensure we haven't already sent headers
    if (!headers_sent()) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
    }
    
    echo json_encode($errorResponse, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

/**
 * Custom error handler that converts PHP errors to exceptions
 * 
 * @param int $severity
 * @param string $message
 * @param string $file
 * @param int $line
 * @throws ErrorException
 */
function globalErrorHandler(int $severity, string $message, string $file, int $line): bool
{
    // Don't throw exception if error reporting is turned off
    if (!(error_reporting() & $severity)) {
        return false;
    }
    
    throw new ErrorException($message, 0, $severity, $file, $line);
}

/**
 * Handle fatal errors that can't be caught by exception handler
 */
function globalShutdownHandler(): void
{
    $error = error_get_last();
    
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        $exception = new ErrorException(
            $error['message'],
            0,
            $error['type'],
            $error['file'],
            $error['line']
        );
        
        globalExceptionHandler($exception);
    }
}

/**
 * Log error details to file
 * 
 * @param Throwable $exception
 */
function logError(Throwable $exception): void
{
    $logDir = __DIR__ . '/../storage/logs';
    $logFile = $logDir . '/app.log';
    
    // Ensure log directory exists
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    // Prepare log entry
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = [
        'timestamp' => $timestamp,
        'level' => 'ERROR',
        'message' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'type' => get_class($exception),
        'code' => $exception->getCode(),
        'trace' => $exception->getTraceAsString(),
        'request' => [
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'CLI',
            'uri' => $_SERVER['REQUEST_URI'] ?? 'N/A',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'N/A',
            'ip' => getRealIpAddress(),
        ]
    ];
    
    // Add user info if available
    try {
        $user = getCurrentUser();
        if ($user) {
            $logEntry['user'] = [
                'id' => $user['id'],
                'email' => $user['email'] ?? 'N/A'
            ];
        }
    } catch (Exception $e) {
        // Ignore auth errors when logging
    }
    
    $logLine = json_encode($logEntry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    
    // Write to log file (append mode)
    file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
    
    // Also log to PHP error log for system administrators
    error_log("HR System Error: " . $exception->getMessage() . " in " . $exception->getFile() . ":" . $exception->getLine());
}

/**
 * Log custom messages
 * 
 * @param string $message Log message
 * @param string $level Log level (INFO, WARNING, ERROR, DEBUG)
 * @param array $context Additional context data
 */
function logMessage(string $message, string $level = 'INFO', array $context = []): void
{
    $logDir = __DIR__ . '/../storage/logs';
    $logFile = $logDir . '/app.log';
    
    // Ensure log directory exists
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = [
        'timestamp' => $timestamp,
        'level' => strtoupper($level),
        'message' => $message,
        'context' => $context,
        'request' => [
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'CLI',
            'uri' => $_SERVER['REQUEST_URI'] ?? 'N/A',
            'ip' => getRealIpAddress(),
        ]
    ];
    
    // Add user info if available
    try {
        $user = getCurrentUser();
        if ($user) {
            $logEntry['user'] = [
                'id' => $user['id'],
                'email' => $user['email'] ?? 'N/A'
            ];
        }
    } catch (Exception $e) {
        // Ignore auth errors when logging
    }
    
    $logLine = json_encode($logEntry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
}

/**
 * Get the real IP address of the client
 * 
 * @return string Client IP address
 */
function getRealIpAddress(): string
{
    $ipKeys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            $ips = explode(',', $_SERVER[$key]);
            $ip = trim($ips[0]);
            
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }
    
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

/**
 * Create a new application exception with HTTP status code
 */
class AppException extends Exception
{
    public function __construct(string $message = "", int $code = 400, Throwable $previous = null)
    {
        // Ensure code is a valid HTTP status code
        if ($code < 100 || $code >= 600) {
            $code = 400;
        }
        
        parent::__construct($message, $code, $previous);
    }
}

/**
 * Create a validation exception (400 Bad Request)
 */
class ValidationException extends AppException
{
    public function __construct(string $message = "Validation failed", Throwable $previous = null)
    {
        parent::__construct($message, 400, $previous);
    }
}

/**
 * Create an authentication exception (401 Unauthorized)
 */
class AuthException extends AppException
{
    public function __construct(string $message = "Authentication required", Throwable $previous = null)
    {
        parent::__construct($message, 401, $previous);
    }
}

/**
 * Create an authorization exception (403 Forbidden)
 */
class AuthorizationException extends AppException
{
    public function __construct(string $message = "Access denied", Throwable $previous = null)
    {
        parent::__construct($message, 403, $previous);
    }
}

/**
 * Create a not found exception (404 Not Found)
 */
class NotFoundException extends AppException
{
    public function __construct(string $message = "Resource not found", Throwable $previous = null)
    {
        parent::__construct($message, 404, $previous);
    }
}

/**
 * Initialize the global error handlers
 */
function initializeErrorHandlers(): void
{
    // Set error reporting based on environment
    $config = getConfig();
    $isDebug = $config['app']['debug'] ?? false;
    
    if ($isDebug) {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    } else {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);
        ini_set('display_errors', '0');
    }
    
    // Set custom handlers
    set_exception_handler('globalExceptionHandler');
    set_error_handler('globalErrorHandler');
    register_shutdown_function('globalShutdownHandler');
    
    // Log startup
    logMessage('Application started', 'INFO', [
        'environment' => $config['app']['env'] ?? 'unknown',
        'debug' => $isDebug
    ]);
}

// Auto-initialize when this file is included
initializeErrorHandlers();
