/**
 * Integration Tests for Backend API Endpoints
 * Tests the PHP backend API functionality
 */

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

// Test configuration
const BASE_URL = process.env.TEST_API_URL || 'http://localhost:8000';
const TEST_USER = {
    email: 'test@example.com',
    password: 'testpassword123'
};

let authToken = null;
let testUserId = null;

describe('API Integration Tests', () => {
    beforeAll(async () => {
        // Wait for server to be ready
        await waitForServer();
    });

    describe('Authentication Endpoints', () => {
        test('POST /api/register.php - should register new user', async () => {
            const response = await axios.post(`${BASE_URL}/api/register.php`, {
                email: TEST_USER.email,
                password: TEST_USER.password,
                first_name: 'Test',
                last_name: 'User'
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
            expect(response.data).toHaveProperty('token');
            expect(response.data).toHaveProperty('user');

            authToken = response.data.token;
            testUserId = response.data.user.id;
        });

        test('POST /api/login.php - should login existing user', async () => {
            const response = await axios.post(`${BASE_URL}/api/login.php`, {
                email: TEST_USER.email,
                password: TEST_USER.password
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
            expect(response.data).toHaveProperty('token');
            expect(response.data).toHaveProperty('user');

            authToken = response.data.token;
        });

        test('POST /api/login.php - should reject invalid credentials', async () => {
            try {
                await axios.post(`${BASE_URL}/api/login.php`, {
                    email: TEST_USER.email,
                    password: 'wrongpassword'
                });
                fail('Should have thrown an error');
            } catch (error) {
                expect(error.response.status).toBe(401);
                expect(error.response.data).toHaveProperty('success', false);
            }
        });

        test('POST /api/logout.php - should logout user', async () => {
            const response = await axios.post(`${BASE_URL}/api/logout.php`, {}, {
                headers: {
                    'Authorization': `Bearer ${authToken}`
                }
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
        });
    });

    describe('Employee Management Endpoints', () => {
        beforeEach(async () => {
            // Ensure we have a valid auth token
            if (!authToken) {
                const response = await axios.post(`${BASE_URL}/api/login.php`, {
                    email: TEST_USER.email,
                    password: TEST_USER.password
                });
                authToken = response.data.token;
            }
        });

        test('GET /api/employees.php - should list employees', async () => {
            const response = await axios.get(`${BASE_URL}/api/employees.php`, {
                headers: {
                    'Authorization': `Bearer ${authToken}`
                }
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
            expect(response.data).toHaveProperty('employees');
            expect(Array.isArray(response.data.employees)).toBe(true);
        });

        test('POST /api/employees.php - should create new employee', async () => {
            const newEmployee = {
                first_name: 'John',
                last_name: 'Doe',
                email: 'john.doe@example.com',
                phone: '+1234567890',
                department: 'Engineering',
                position: 'Software Engineer',
                hire_date: '2024-01-15',
                salary: 75000
            };

            const response = await axios.post(`${BASE_URL}/api/employees.php`, newEmployee, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
            expect(response.data).toHaveProperty('employee');
            expect(response.data.employee).toHaveProperty('id');
            expect(response.data.employee.first_name).toBe(newEmployee.first_name);
        });

        test('PUT /api/employees.php - should update employee', async () => {
            // First create an employee
            const newEmployee = {
                first_name: 'Jane',
                last_name: 'Smith',
                email: 'jane.smith@example.com',
                department: 'Marketing',
                position: 'Marketing Manager'
            };

            const createResponse = await axios.post(`${BASE_URL}/api/employees.php`, newEmployee, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });

            const employeeId = createResponse.data.employee.id;

            // Update the employee
            const updateData = {
                id: employeeId,
                first_name: 'Jane Updated',
                salary: 85000
            };

            const response = await axios.put(`${BASE_URL}/api/employees.php`, updateData, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
            expect(response.data.employee.first_name).toBe('Jane Updated');
            expect(response.data.employee.salary).toBe(85000);
        });

        test('DELETE /api/employees.php - should delete employee', async () => {
            // First create an employee
            const newEmployee = {
                first_name: 'Delete',
                last_name: 'Test',
                email: 'delete.test@example.com',
                department: 'Testing'
            };

            const createResponse = await axios.post(`${BASE_URL}/api/employees.php`, newEmployee, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });

            const employeeId = createResponse.data.employee.id;

            // Delete the employee
            const response = await axios.delete(`${BASE_URL}/api/employees.php`, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                },
                data: { id: employeeId }
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
        });
    });

    describe('File Management Endpoints', () => {
        beforeEach(async () => {
            // Ensure we have a valid auth token
            if (!authToken) {
                const response = await axios.post(`${BASE_URL}/api/login.php`, {
                    email: TEST_USER.email,
                    password: TEST_USER.password
                });
                authToken = response.data.token;
            }
        });

        test('POST /api/files.php - should upload file', async () => {
            // Create a test file
            const testFilePath = path.join(__dirname, 'test-file.txt');
            fs.writeFileSync(testFilePath, 'This is a test file content');

            const formData = new FormData();
            formData.append('file', fs.createReadStream(testFilePath));

            const response = await axios.post(`${BASE_URL}/api/files.php`, formData, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    ...formData.getHeaders()
                }
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
            expect(response.data).toHaveProperty('file');
            expect(response.data.file).toHaveProperty('id');

            // Clean up test file
            fs.unlinkSync(testFilePath);
        });

        test('GET /api/files.php - should list files', async () => {
            const response = await axios.get(`${BASE_URL}/api/files.php`, {
                headers: {
                    'Authorization': `Bearer ${authToken}`
                }
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);
            expect(response.data).toHaveProperty('files');
            expect(Array.isArray(response.data.files)).toBe(true);
        });

        test('DELETE /api/files.php - should delete file', async () => {
            // First upload a file
            const testFilePath = path.join(__dirname, 'test-delete-file.txt');
            fs.writeFileSync(testFilePath, 'Test file for deletion');

            const formData = new FormData();
            formData.append('file', fs.createReadStream(testFilePath));

            const uploadResponse = await axios.post(`${BASE_URL}/api/files.php`, formData, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    ...formData.getHeaders()
                }
            });

            const fileId = uploadResponse.data.file.id;

            // Delete the file
            const response = await axios.delete(`${BASE_URL}/api/files.php`, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                },
                data: { id: fileId }
            });

            expect(response.status).toBe(200);
            expect(response.data).toHaveProperty('success', true);

            // Clean up test file
            fs.unlinkSync(testFilePath);
        });
    });

    describe('Error Handling', () => {
        test('should return 401 for unauthorized requests', async () => {
            try {
                await axios.get(`${BASE_URL}/api/employees.php`);
                fail('Should have thrown an error');
            } catch (error) {
                expect(error.response.status).toBe(401);
            }
        });

        test('should return 400 for invalid request data', async () => {
            try {
                await axios.post(`${BASE_URL}/api/employees.php`, {
                    // Missing required fields
                }, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                fail('Should have thrown an error');
            } catch (error) {
                expect(error.response.status).toBe(400);
            }
        });

        test('should return 404 for non-existent endpoints', async () => {
            try {
                await axios.get(`${BASE_URL}/api/nonexistent.php`);
                fail('Should have thrown an error');
            } catch (error) {
                expect(error.response.status).toBe(404);
            }
        });
    });

    describe('CORS Headers', () => {
        test('should include proper CORS headers', async () => {
            const response = await axios.options(`${BASE_URL}/api/employees.php`);
            
            expect(response.headers).toHaveProperty('access-control-allow-origin');
            expect(response.headers).toHaveProperty('access-control-allow-methods');
            expect(response.headers).toHaveProperty('access-control-allow-headers');
        });
    });
});

// Helper function to wait for server to be ready
async function waitForServer() {
    const maxAttempts = 30;
    let attempts = 0;

    while (attempts < maxAttempts) {
        try {
            await axios.get(`${BASE_URL}/api/health.php`);
            console.log('Server is ready');
            return;
        } catch (error) {
            attempts++;
            if (attempts >= maxAttempts) {
                throw new Error('Server failed to start within timeout');
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }
}

// Cleanup after all tests
afterAll(async () => {
    // Clean up test data if needed
    if (authToken) {
        try {
            await axios.post(`${BASE_URL}/api/logout.php`, {}, {
                headers: {
                    'Authorization': `Bearer ${authToken}`
                }
            });
        } catch (error) {
            // Ignore cleanup errors
        }
    }
}); 