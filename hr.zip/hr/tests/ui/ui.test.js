/**
 * UI Tests for HR Management System
 * Tests the frontend user interface using Playwright
 */

const { test, expect } = require('@playwright/test');

// Test configuration
const BASE_URL = process.env.TEST_FRONTEND_URL || 'http://localhost:3000';
const TEST_USER = {
    email: 'test@example.com',
    password: 'testpassword123'
};

test.describe('HR Management System UI Tests', () => {
    test.beforeEach(async ({ page }) => {
        // Navigate to the application
        await page.goto(BASE_URL);
        
        // Wait for the page to load
        await page.waitForLoadState('networkidle');
    });

    test.describe('Authentication UI', () => {
        test('should show login modal on page load', async ({ page }) => {
            // Check if login modal is visible
            const loginModal = page.locator('#loginModal');
            await expect(loginModal).toBeVisible();
            
            // Check if login form is present
            const loginForm = page.locator('#loginForm');
            await expect(loginForm).toBeVisible();
        });

        test('should switch between login and register modals', async ({ page }) => {
            // Click on register link
            await page.click('#showRegister');
            
            // Check if register modal is visible
            const registerModal = page.locator('#registerModal');
            await expect(registerModal).toBeVisible();
            
            // Check if login modal is hidden
            const loginModal = page.locator('#loginModal');
            await expect(loginModal).not.toBeVisible();
            
            // Switch back to login
            await page.click('#showLogin');
            await expect(loginModal).toBeVisible();
            await expect(registerModal).not.toBeVisible();
        });

        test('should show password visibility toggle', async ({ page }) => {
            const passwordInput = page.locator('#password');
            const eyeIcon = page.locator('.password-toggle');
            
            // Check if password is hidden by default
            await expect(passwordInput).toHaveAttribute('type', 'password');
            
            // Click eye icon to show password
            await eyeIcon.click();
            await expect(passwordInput).toHaveAttribute('type', 'text');
            
            // Click again to hide password
            await eyeIcon.click();
            await expect(passwordInput).toHaveAttribute('type', 'password');
        });

        test('should handle login form submission', async ({ page }) => {
            // Fill login form
            await page.fill('#email', TEST_USER.email);
            await page.fill('#password', TEST_USER.password);
            
            // Submit form
            await page.click('#loginForm button[type="submit"]');
            
            // Check for loading state
            const loadingOverlay = page.locator('#loadingOverlay');
            await expect(loadingOverlay).toBeVisible();
            
            // Wait for response (this will fail if backend is not running)
            try {
                await page.waitForFunction(() => {
                    return !document.getElementById('loadingOverlay').style.display.includes('flex');
                }, { timeout: 5000 });
            } catch (error) {
                // Expected if backend is not running
                console.log('Backend not available for login test');
            }
        });

        test('should show forgot password dialog', async ({ page }) => {
            // Click forgot password link
            await page.click('#forgotPassword');
            
            // Check if prompt appears (browser dialog)
            // Note: Playwright handles dialogs automatically
            const dialog = page.locator('text=Please enter your email address:');
            // This test will depend on how the forgot password is implemented
        });
    });

    test.describe('Dashboard UI', () => {
        test.beforeEach(async ({ page }) => {
            // Mock authentication by setting localStorage
            await page.evaluate((user) => {
                localStorage.setItem('authToken', 'mock-token');
                localStorage.setItem('currentUser', JSON.stringify({
                    id: '123',
                    email: user.email,
                    user_metadata: { first_name: 'Test', last_name: 'User' }
                }));
            }, TEST_USER);
            
            // Reload page to trigger auth check
            await page.reload();
        });

        test('should show dashboard after authentication', async ({ page }) => {
            // Check if login modal is hidden
            const loginModal = page.locator('#loginModal');
            await expect(loginModal).not.toBeVisible();
            
            // Check if dashboard is visible
            const dashboard = page.locator('.dashboard');
            await expect(dashboard).toBeVisible();
        });

        test('should display user profile information', async ({ page }) => {
            // Check if profile name is displayed
            const profileName = page.locator('#profileName');
            await expect(profileName).toContainText('Test User');
            
            // Check if profile email is displayed
            const profileEmail = page.locator('#profileEmail');
            await expect(profileEmail).toContainText(TEST_USER.email);
        });

        test('should show navigation menu', async ({ page }) => {
            // Check if navigation items are present
            const navItems = page.locator('.nav-item');
            await expect(navItems).toHaveCount(4); // Dashboard, Employees, Files, Profile
            
            // Check specific nav items
            await expect(page.locator('text=Dashboard')).toBeVisible();
            await expect(page.locator('text=Employees')).toBeVisible();
            await expect(page.locator('text=Files')).toBeVisible();
            await expect(page.locator('text=Profile')).toBeVisible();
        });

        test('should handle logout', async ({ page }) => {
            // Click logout button
            await page.click('#logoutBtn');
            
            // Check if login modal appears
            const loginModal = page.locator('#loginModal');
            await expect(loginModal).toBeVisible();
            
            // Check if dashboard is hidden
            const dashboard = page.locator('.dashboard');
            await expect(dashboard).not.toBeVisible();
        });
    });

    test.describe('Employee Management UI', () => {
        test.beforeEach(async ({ page }) => {
            // Mock authentication
            await page.evaluate((user) => {
                localStorage.setItem('authToken', 'mock-token');
                localStorage.setItem('currentUser', JSON.stringify({
                    id: '123',
                    email: user.email
                }));
            }, TEST_USER);
            
            await page.reload();
            
            // Navigate to employees section
            await page.click('text=Employees');
        });

        test('should show employee management interface', async ({ page }) => {
            // Check if employee section is visible
            const employeeSection = page.locator('.employee-section');
            await expect(employeeSection).toBeVisible();
            
            // Check if add employee button is present
            const addButton = page.locator('#addEmployeeBtn');
            await expect(addButton).toBeVisible();
        });

        test('should open add employee modal', async ({ page }) => {
            // Click add employee button
            await page.click('#addEmployeeBtn');
            
            // Check if modal is visible
            const modal = page.locator('#employeeModal');
            await expect(modal).toBeVisible();
            
            // Check if form fields are present
            await expect(page.locator('#employeeFirstName')).toBeVisible();
            await expect(page.locator('#employeeLastName')).toBeVisible();
            await expect(page.locator('#employeeEmail')).toBeVisible();
            await expect(page.locator('#employeeDepartment')).toBeVisible();
        });

        test('should fill and submit employee form', async ({ page }) => {
            // Open add employee modal
            await page.click('#addEmployeeBtn');
            
            // Fill form
            await page.fill('#employeeFirstName', 'John');
            await page.fill('#employeeLastName', 'Doe');
            await page.fill('#employeeEmail', 'john.doe@example.com');
            await page.selectOption('#employeeDepartment', 'Engineering');
            await page.fill('#employeePosition', 'Software Engineer');
            await page.fill('#employeeSalary', '75000');
            
            // Submit form
            await page.click('#employeeModal button[type="submit"]');
            
            // Check for success message
            const toast = page.locator('.toast.success');
            await expect(toast).toBeVisible();
        });

        test('should search and filter employees', async ({ page }) => {
            // Check if search input is present
            const searchInput = page.locator('#employeeSearch');
            await expect(searchInput).toBeVisible();
            
            // Type in search
            await searchInput.fill('John');
            
            // Check if search results update
            await page.waitForTimeout(500); // Wait for search debounce
            
            // Verify search functionality (this depends on implementation)
        });
    });

    test.describe('File Management UI', () => {
        test.beforeEach(async ({ page }) => {
            // Mock authentication
            await page.evaluate((user) => {
                localStorage.setItem('authToken', 'mock-token');
                localStorage.setItem('currentUser', JSON.stringify({
                    id: '123',
                    email: user.email
                }));
            }, TEST_USER);
            
            await page.reload();
            
            // Navigate to files section
            await page.click('text=Files');
        });

        test('should show file management interface', async ({ page }) => {
            // Check if file section is visible
            const fileSection = page.locator('.file-section');
            await expect(fileSection).toBeVisible();
            
            // Check if upload area is present
            const uploadArea = page.locator('#fileUploadArea');
            await expect(uploadArea).toBeVisible();
        });

        test('should handle file upload', async ({ page }) => {
            // Create a test file
            const testFile = {
                name: 'test-document.txt',
                mimeType: 'text/plain',
                buffer: Buffer.from('This is a test file content')
            };
            
            // Upload file
            await page.setInputFiles('#fileInput', testFile);
            
            // Check if upload progress is shown
            const progressBar = page.locator('.upload-progress');
            await expect(progressBar).toBeVisible();
            
            // Wait for upload to complete
            await page.waitForFunction(() => {
                return !document.querySelector('.upload-progress').style.display.includes('block');
            }, { timeout: 10000 });
            
            // Check for success message
            const toast = page.locator('.toast.success');
            await expect(toast).toBeVisible();
        });

        test('should show file list', async ({ page }) => {
            // Check if file list container is present
            const fileList = page.locator('#fileList');
            await expect(fileList).toBeVisible();
            
            // Check if file items can be displayed
            // This depends on whether there are files in the system
        });
    });

    test.describe('Responsive Design', () => {
        test('should work on mobile viewport', async ({ page }) => {
            // Set mobile viewport
            await page.setViewportSize({ width: 375, height: 667 });
            
            // Check if mobile menu is accessible
            const mobileMenu = page.locator('.mobile-menu-toggle');
            if (await mobileMenu.isVisible()) {
                await mobileMenu.click();
                
                // Check if mobile menu opens
                const mobileNav = page.locator('.mobile-nav');
                await expect(mobileNav).toBeVisible();
            }
        });

        test('should work on tablet viewport', async ({ page }) => {
            // Set tablet viewport
            await page.setViewportSize({ width: 768, height: 1024 });
            
            // Check if layout adapts properly
            const mainContent = page.locator('.main-content');
            await expect(mainContent).toBeVisible();
        });

        test('should work on desktop viewport', async ({ page }) => {
            // Set desktop viewport
            await page.setViewportSize({ width: 1920, height: 1080 });
            
            // Check if layout is optimal for desktop
            const sidebar = page.locator('.sidebar');
            await expect(sidebar).toBeVisible();
        });
    });

    test.describe('Theme Switching', () => {
        test('should toggle between light and dark themes', async ({ page }) => {
            // Mock authentication
            await page.evaluate((user) => {
                localStorage.setItem('authToken', 'mock-token');
                localStorage.setItem('currentUser', JSON.stringify({
                    id: '123',
                    email: user.email
                }));
            }, TEST_USER);
            
            await page.reload();
            
            // Find theme toggle
            const themeToggle = page.locator('#theme-toggle');
            await expect(themeToggle).toBeVisible();
            
            // Check initial theme (should be light by default)
            await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
            
            // Toggle to dark theme
            await themeToggle.click();
            await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
            
            // Toggle back to light theme
            await themeToggle.click();
            await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
        });
    });

    test.describe('Error Handling', () => {
        test('should show error messages for invalid login', async ({ page }) => {
            // Fill login form with invalid data
            await page.fill('#email', 'invalid@example.com');
            await page.fill('#password', 'wrongpassword');
            
            // Submit form
            await page.click('#loginForm button[type="submit"]');
            
            // Check for error message
            const errorToast = page.locator('.toast.error');
            await expect(errorToast).toBeVisible();
        });

        test('should handle network errors gracefully', async ({ page }) => {
            // Mock network error by intercepting requests
            await page.route('**/api/**', route => {
                route.abort('failed');
            });
            
            // Try to login
            await page.fill('#email', TEST_USER.email);
            await page.fill('#password', TEST_USER.password);
            await page.click('#loginForm button[type="submit"]');
            
            // Check for error message
            const errorToast = page.locator('.toast.error');
            await expect(errorToast).toBeVisible();
        });
    });
});

// Helper function to create test data
async function createTestEmployee(page) {
    await page.click('#addEmployeeBtn');
    await page.fill('#employeeFirstName', 'Test');
    await page.fill('#employeeLastName', 'Employee');
    await page.fill('#employeeEmail', 'test.employee@example.com');
    await page.selectOption('#employeeDepartment', 'Engineering');
    await page.fill('#employeePosition', 'Developer');
    await page.click('#employeeModal button[type="submit"]');
    
    // Wait for success message
    await page.waitForSelector('.toast.success');
} 