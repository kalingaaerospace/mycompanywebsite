<?php

/**
 * Authentication Rate Limiter
 * Enhanced rate limiting specifically for authentication endpoints
 * with progressive backoff and brute-force protection
 */

require_once __DIR__ . '/../config/bootstrap.php';
require_once __DIR__ . '/../config/error_handler.php';

class AuthRateLimiter
{
    private $cacheDir;
    
    public function __construct()
    {
        $this->cacheDir = __DIR__ . '/../storage/cache/auth_rate_limits';
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0755, true);
        }
    }
    
    /**
     * Check and apply rate limiting for authentication endpoints
     * 
     * @param string $identifier Rate limit identifier (IP, email, etc.)
     * @param string $endpoint Endpoint type (login, register, etc.)
     * @param int $maxAttempts Maximum attempts allowed
     * @param int $timeWindow Time window in seconds
     * @throws AppException If rate limit exceeded
     */
    public function checkRateLimit(string $identifier, string $endpoint, int $maxAttempts = 10, int $timeWindow = 3600): void
    {
        $cacheKey = $this->generateCacheKey($identifier, $endpoint);
        $cacheFile = $this->cacheDir . '/' . $cacheKey . '.json';
        $now = time();
        
        // Load existing rate limit data
        $rateLimitData = $this->loadRateLimitData($cacheFile, $now);
        
        // Apply progressive backoff for repeated failures
        $backoffMultiplier = $this->calculateBackoffMultiplier($rateLimitData['failures'] ?? 0);
        $adjustedTimeWindow = $timeWindow * $backoffMultiplier;
        
        // Initialize or update rate limit data
        if (empty($rateLimitData) || $rateLimitData['expires'] <= $now) {
            $rateLimitData = [
                'attempts' => 1,
                'failures' => $rateLimitData['failures'] ?? 0, // Preserve failure count
                'expires' => $now + $adjustedTimeWindow,
                'reset_time' => $now + $adjustedTimeWindow,
                'first_attempt' => $now,
                'last_attempt' => $now
            ];
        } else {
            $rateLimitData['attempts']++;
            $rateLimitData['last_attempt'] = $now;
        }
        
        // Check if rate limit exceeded
        if ($rateLimitData['attempts'] > $maxAttempts) {
            // Add rate limit headers
            $this->setRateLimitHeaders($maxAttempts, 0, $rateLimitData['reset_time']);
            
            // Log rate limit violation
            logMessage('Authentication rate limit exceeded', 'WARNING', [
                'identifier' => hash('sha256', $identifier), // Hash for privacy
                'endpoint' => $endpoint,
                'attempts' => $rateLimitData['attempts'],
                'max_attempts' => $maxAttempts,
                'time_window' => $adjustedTimeWindow,
                'ip' => getRealIpAddress()
            ]);
            
            $waitTime = $rateLimitData['reset_time'] - $now;
            throw new AppException(
                "Too many {$endpoint} attempts. Please try again in " . $this->formatWaitTime($waitTime) . ".", 
                429
            );
        }
        
        // Save updated rate limit data
        $this->saveRateLimitData($cacheFile, $rateLimitData);
        
        // Add rate limit headers
        $remaining = max(0, $maxAttempts - $rateLimitData['attempts']);
        $this->setRateLimitHeaders($maxAttempts, $remaining, $rateLimitData['reset_time']);
    }
    
    /**
     * Record a failed authentication attempt
     * 
     * @param string $identifier Rate limit identifier
     * @param string $endpoint Endpoint type
     */
    public function recordFailure(string $identifier, string $endpoint): void
    {
        $cacheKey = $this->generateCacheKey($identifier, $endpoint);
        $cacheFile = $this->cacheDir . '/' . $cacheKey . '.json';
        $now = time();
        
        $rateLimitData = $this->loadRateLimitData($cacheFile, $now);
        $rateLimitData['failures'] = ($rateLimitData['failures'] ?? 0) + 1;
        $rateLimitData['last_failure'] = $now;
        
        // Extend the rate limit window after failures
        if ($rateLimitData['failures'] >= 3) {
            $backoffMultiplier = $this->calculateBackoffMultiplier($rateLimitData['failures']);
            $rateLimitData['expires'] = $now + (3600 * $backoffMultiplier); // Base 1 hour window
            $rateLimitData['reset_time'] = $rateLimitData['expires'];
        }
        
        $this->saveRateLimitData($cacheFile, $rateLimitData);
    }
    
    /**
     * Record a successful authentication (resets failure count)
     * 
     * @param string $identifier Rate limit identifier
     * @param string $endpoint Endpoint type
     */
    public function recordSuccess(string $identifier, string $endpoint): void
    {
        $cacheKey = $this->generateCacheKey($identifier, $endpoint);
        $cacheFile = $this->cacheDir . '/' . $cacheKey . '.json';
        
        // Reset failure count on successful authentication
        if (file_exists($cacheFile)) {
            $rateLimitData = $this->loadRateLimitData($cacheFile, time());
            $rateLimitData['failures'] = 0;
            $rateLimitData['last_success'] = time();
            $this->saveRateLimitData($cacheFile, $rateLimitData);
        }
    }
    
    /**
     * Generate cache key for rate limiting
     */
    private function generateCacheKey(string $identifier, string $endpoint): string
    {
        return 'auth_' . $endpoint . '_' . hash('sha256', $identifier);
    }
    
    /**
     * Load rate limit data from cache file
     */
    private function loadRateLimitData(string $cacheFile, int $now): array
    {
        if (!file_exists($cacheFile)) {
            return [];
        }
        
        $data = json_decode(file_get_contents($cacheFile), true);
        if (!$data || !is_array($data)) {
            return [];
        }
        
        // Check if data has expired
        if (isset($data['expires']) && $data['expires'] <= $now) {
            // Reset attempts but preserve failure count for progressive backoff
            return [
                'failures' => $data['failures'] ?? 0,
                'last_failure' => $data['last_failure'] ?? null
            ];
        }
        
        return $data;
    }
    
    /**
     * Save rate limit data to cache file
     */
    private function saveRateLimitData(string $cacheFile, array $data): void
    {
        file_put_contents($cacheFile, json_encode($data), LOCK_EX);
    }
    
    /**
     * Calculate backoff multiplier based on failure count
     */
    private function calculateBackoffMultiplier(int $failures): float
    {
        // Progressive backoff: 1x, 2x, 4x, 8x, max 16x
        return min(16, pow(2, max(0, $failures - 2)));
    }
    
    /**
     * Set rate limit headers
     */
    private function setRateLimitHeaders(int $limit, int $remaining, int $resetTime): void
    {
        header('X-RateLimit-Limit: ' . $limit);
        header('X-RateLimit-Remaining: ' . $remaining);
        header('X-RateLimit-Reset: ' . $resetTime);
        header('Retry-After: ' . max(0, $resetTime - time()));
    }
    
    /**
     * Format wait time for user-friendly display
     */
    private function formatWaitTime(int $seconds): string
    {
        if ($seconds < 60) {
            return $seconds . ' seconds';
        } elseif ($seconds < 3600) {
            return ceil($seconds / 60) . ' minutes';
        } else {
            return ceil($seconds / 3600) . ' hours';
        }
    }
    
    /**
     * Clean up expired rate limit files (maintenance function)
     */
    public function cleanup(): void
    {
        $files = glob($this->cacheDir . '/*.json');
        $now = time();
        $cleaned = 0;
        
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            if ($data && isset($data['expires']) && $data['expires'] < ($now - 86400)) { // 24 hours old
                unlink($file);
                $cleaned++;
            }
        }
        
        if ($cleaned > 0) {
            logMessage('Cleaned up expired rate limit files', 'INFO', ['files_cleaned' => $cleaned]);
        }
    }
}

// Global helper functions for easier usage

/**
 * Apply authentication rate limiting
 */
function applyAuthRateLimit(string $identifier, string $endpoint = 'auth', int $maxAttempts = 10, int $timeWindow = 3600): void
{
    static $rateLimiter = null;
    if ($rateLimiter === null) {
        $rateLimiter = new AuthRateLimiter();
    }
    
    $rateLimiter->checkRateLimit($identifier, $endpoint, $maxAttempts, $timeWindow);
}

/**
 * Record authentication failure
 */
function recordAuthFailure(string $identifier, string $endpoint = 'auth'): void
{
    static $rateLimiter = null;
    if ($rateLimiter === null) {
        $rateLimiter = new AuthRateLimiter();
    }
    
    $rateLimiter->recordFailure($identifier, $endpoint);
}

/**
 * Record authentication success
 */
function recordAuthSuccess(string $identifier, string $endpoint = 'auth'): void
{
    static $rateLimiter = null;
    if ($rateLimiter === null) {
        $rateLimiter = new AuthRateLimiter();
    }
    
    $rateLimiter->recordSuccess($identifier, $endpoint);
}
