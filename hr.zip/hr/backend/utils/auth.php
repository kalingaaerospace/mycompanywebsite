<?php

/**
 * Authentication Utilities
 * JWT token handling, CORS setup, and JSON response helpers
 */

require_once __DIR__ . '/../config/bootstrap.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;

/**
 * Generate custom JWT token wrapping Supabase user data
 * 
 * @param array $supabaseUser Supabase user object
 * @param array $customClaims Additional claims to include
 * @return string JWT token
 * @throws Exception
 */
function generateJwt(array $supabaseUser, array $customClaims = []): string
{
    $config = getConfig();
    $secret = $config['jwt']['secret'];
    $algorithm = $config['jwt']['algorithm'];
    
    if (empty($secret) || $secret === 'default_secret_change_in_production') {
        throw new Exception('JWT secret not configured properly');
    }

    $issuedAt = time();
    $expirationTime = $issuedAt + (24 * 60 * 60); // 24 hours
    
    $payload = [
        'iss' => $config['app']['url'], // Issuer
        'aud' => $config['app']['url'], // Audience
        'iat' => $issuedAt,            // Issued at
        'exp' => $expirationTime,      // Expiration time
        'sub' => $supabaseUser['id'],  // Subject (user ID)
        
        // Supabase user data
        'user' => [
            'id' => $supabaseUser['id'],
            'email' => $supabaseUser['email'] ?? null,
            'email_confirmed_at' => $supabaseUser['email_confirmed_at'] ?? null,
            'phone' => $supabaseUser['phone'] ?? null,
            'phone_confirmed_at' => $supabaseUser['phone_confirmed_at'] ?? null,
            'user_metadata' => $supabaseUser['user_metadata'] ?? [],
            'app_metadata' => $supabaseUser['app_metadata'] ?? [],
            'role' => $supabaseUser['role'] ?? 'authenticated',
            'created_at' => $supabaseUser['created_at'] ?? null,
            'updated_at' => $supabaseUser['updated_at'] ?? null,
        ],
        
        // Custom claims
        'custom' => $customClaims
    ];

    return JWT::encode($payload, $secret, $algorithm);
}

/**
 * Validate JWT token and return payload
 * 
 * @param string|null $token JWT token (if null, attempts to extract from headers)
 * @return array JWT payload
 * @throws Exception On validation failure (HTTP 401)
 */
function validateJwt(?string $token = null): array
{
    try {
        if ($token === null) {
            $token = extractTokenFromRequest();
        }
        
        if (empty($token)) {
            http_response_code(401);
            throw new Exception('Authorization token required');
        }

        $config = getConfig();
        $secret = $config['jwt']['secret'];
        $algorithm = $config['jwt']['algorithm'];
        
        if (empty($secret) || $secret === 'default_secret_change_in_production') {
            throw new Exception('JWT secret not configured properly');
        }

        $decoded = JWT::decode($token, new Key($secret, $algorithm));
        return (array) $decoded;

    } catch (ExpiredException $e) {
        http_response_code(401);
        throw new Exception('Token expired');
    } catch (SignatureInvalidException $e) {
        http_response_code(401);
        throw new Exception('Invalid token signature');
    } catch (Exception $e) {
        http_response_code(401);
        throw new Exception('Invalid token: ' . $e->getMessage());
    }
}

/**
 * Extract JWT token from Authorization header or query parameter
 * 
 * @return string|null Token or null if not found
 */
function extractTokenFromRequest(): ?string
{
    // Try Authorization header first
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        $authHeader = $headers['Authorization'];
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return $matches[1];
        }
    }

    // Fallback to query parameter
    return $_GET['token'] ?? null;
}

/**
 * Get current authenticated user from JWT token
 * 
 * @return array|null User data or null if not authenticated
 */
function getCurrentUser(): ?array
{
    try {
        $payload = validateJwt();
        return $payload['user'] ?? null;
    } catch (Exception $e) {
        return null;
    }
}

/**
 * Setup CORS headers for cross-origin requests
 * 
 * @param array $allowedOrigins Allowed origin domains
 * @param array $allowedMethods Allowed HTTP methods
 * @param array $allowedHeaders Allowed headers
 * @param int $maxAge Cache duration for preflight requests
 */
function setupCors(
    array $allowedOrigins = ['*'], 
    array $allowedMethods = ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    array $allowedHeaders = ['Content-Type', 'Authorization', 'X-Requested-With'],
    int $maxAge = 86400
): void {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    
    // Check if origin is allowed
    if (in_array('*', $allowedOrigins) || in_array($origin, $allowedOrigins)) {
        header('Access-Control-Allow-Origin: ' . ($origin ?: '*'));
    }
    
    header('Access-Control-Allow-Methods: ' . implode(', ', $allowedMethods));
    header('Access-Control-Allow-Headers: ' . implode(', ', $allowedHeaders));
    header('Access-Control-Max-Age: ' . $maxAge);
    header('Access-Control-Allow-Credentials: true');
    
    // Handle preflight OPTIONS request
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }
}

/**
 * Send JSON response with proper headers
 * 
 * @param mixed $data Data to send
 * @param int $statusCode HTTP status code
 * @param array $headers Additional headers
 */
function sendJsonResponse($data, int $statusCode = 200, array $headers = []): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    
    // Add additional headers
    foreach ($headers as $name => $value) {
        header($name . ': ' . $value);
    }
    
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

/**
 * Send success JSON response
 * 
 * @param mixed $data Response data
 * @param string $message Success message
 * @param int $statusCode HTTP status code
 */
function sendSuccessResponse($data = null, string $message = 'Success', int $statusCode = 200): void
{
    $response = [
        'success' => true,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    sendJsonResponse($response, $statusCode);
}

/**
 * Send error JSON response
 * 
 * @param string $message Error message
 * @param int $statusCode HTTP status code
 * @param mixed $details Additional error details
 */
function sendErrorResponse(string $message, int $statusCode = 400, $details = null): void
{
    $response = [
        'success' => false,
        'error' => $message
    ];
    
    if ($details !== null) {
        $response['details'] = $details;
    }
    
    sendJsonResponse($response, $statusCode);
}

/**
 * Validate required fields in request data
 * 
 * @param array $data Request data
 * @param array $requiredFields Required field names
 * @throws Exception If validation fails
 */
function validateRequiredFields(array $data, array $requiredFields): void
{
    $missingFields = [];
    
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || (is_string($data[$field]) && trim($data[$field]) === '')) {
            $missingFields[] = $field;
        }
    }
    
    if (!empty($missingFields)) {
        throw new Exception('Missing required fields: ' . implode(', ', $missingFields));
    }
}

/**
 * Sanitize input data
 * 
 * @param mixed $data Data to sanitize
 * @return mixed Sanitized data
 */
function sanitizeInput($data)
{
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    
    if (is_string($data)) {
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
    
    return $data;
}

/**
 * Get request body as array (handles JSON)
 * 
 * @return array Request body data
 */
function getRequestBody(): array
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    
    if (strpos($contentType, 'application/json') !== false) {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        return is_array($data) ? $data : [];
    }
    
    return $_POST;
}

/**
 * Check if user has required role
 * 
 * @param string $requiredRole Required role
 * @param array|null $user User data (if null, gets current user)
 * @return bool True if user has required role
 */
function hasRole(string $requiredRole, ?array $user = null): bool
{
    if ($user === null) {
        $user = getCurrentUser();
    }
    
    if (!$user) {
        return false;
    }
    
    $userRole = $user['role'] ?? 'authenticated';
    
    // Define role hierarchy
    $roleHierarchy = [
        'admin' => ['admin', 'manager', 'employee', 'authenticated'],
        'manager' => ['manager', 'employee', 'authenticated'],
        'employee' => ['employee', 'authenticated'],
        'authenticated' => ['authenticated']
    ];
    
    return in_array($requiredRole, $roleHierarchy[$userRole] ?? []);
}

/**
 * Require authentication (throws 401 if not authenticated)
 * 
 * @param string|null $requiredRole Required role (optional)
 * @return array User data
 * @throws Exception On authentication failure
 */
function requireAuth(?string $requiredRole = null): array
{
    $payload = validateJwt(); // This throws 401 on failure
    $user = $payload['user'] ?? null;
    
    if (!$user) {
        http_response_code(401);
        throw new Exception('User data not found in token');
    }
    
    if ($requiredRole && !hasRole($requiredRole, $user)) {
        http_response_code(403);
        throw new Exception('Insufficient permissions');
    }
    
    return $user;
}

/**
 * Generate secure random token for various purposes
 * 
 * @param int $length Token length
 * @return string Random token
 */
function generateSecureToken(int $length = 32): string
{
    return bin2hex(random_bytes($length / 2));
}

/**
 * Hash password securely
 * 
 * @param string $password Plain text password
 * @return string Hashed password
 */
function hashPassword(string $password): string
{
    return password_hash($password, PASSWORD_ARGON2ID);
}

/**
 * Verify password against hash
 * 
 * @param string $password Plain text password
 * @param string $hash Hashed password
 * @return bool True if password matches
 */
function verifyPassword(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}
