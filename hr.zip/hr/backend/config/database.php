<?php

/**
 * Supabase Database Helper Class
 * Provides wrapper methods for Supabase REST API and Storage operations
 */

require_once __DIR__ . '/bootstrap.php';

use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ServerException;

class SupabaseDatabase
{
    private $restClient;
    private $storageClient;
    private $config;

    public function __construct()
    {
        $this->restClient = getSupabaseRestClient();
        $this->storageClient = getSupabaseStorageClient();
        $this->config = getConfig();
    }

    /**
     * Perform SELECT query on a table
     * 
     * @param string $table Table name
     * @param array $select Columns to select (default: ['*'])
     * @param array $filters WHERE conditions
     * @param array $options Additional options (limit, order, etc.)
     * @return array
     * @throws Exception
     */
    public function select(string $table, array $select = ['*'], array $filters = [], array $options = []): array
    {
        try {
            $url = $table;
            $params = [
                'select' => implode(',', $select)
            ];

            // Add filters
            foreach ($filters as $column => $value) {
                if (is_array($value)) {
                    // Handle operators like ['gte', 18] or ['in', ['active', 'pending']]
                    $operator = $value[0];
                    $filterValue = $value[1];
                    
                    if (is_array($filterValue)) {
                        $params[$column] = $operator . '.(' . implode(',', $filterValue) . ')';
                    } else {
                        $params[$column] = $operator . '.' . $filterValue;
                    }
                } else {
                    $params[$column] = 'eq.' . $value;
                }
            }

            // Add options
            if (isset($options['limit'])) {
                $params['limit'] = $options['limit'];
            }
            if (isset($options['order'])) {
                $params['order'] = $options['order'];
            }
            if (isset($options['offset'])) {
                $params['offset'] = $options['offset'];
            }

            $response = $this->restClient->get($url, ['query' => $params]);
            return json_decode($response->getBody()->getContents(), true);

        } catch (ClientException $e) {
            $this->handleException($e, 'SELECT');
        } catch (ServerException $e) {
            $this->handleException($e, 'SELECT');
        } catch (RequestException $e) {
            $this->handleException($e, 'SELECT');
        }
    }

    /**
     * Insert data into a table
     * 
     * @param string $table Table name
     * @param array $data Data to insert
     * @param bool $upsert Whether to perform upsert (default: false)
     * @return array
     * @throws Exception
     */
    public function insert(string $table, array $data, bool $upsert = false): array
    {
        try {
            $headers = [];
            if ($upsert) {
                $headers['Prefer'] = 'resolution=merge-duplicates,return=representation';
            } else {
                $headers['Prefer'] = 'return=representation';
            }

            $response = $this->restClient->post($table, [
                'json' => $data,
                'headers' => $headers
            ]);

            return json_decode($response->getBody()->getContents(), true);

        } catch (ClientException $e) {
            $this->handleException($e, 'INSERT');
        } catch (ServerException $e) {
            $this->handleException($e, 'INSERT');
        } catch (RequestException $e) {
            $this->handleException($e, 'INSERT');
        }
    }

    /**
     * Update data in a table
     * 
     * @param string $table Table name
     * @param array $data Data to update
     * @param array $filters WHERE conditions
     * @return array
     * @throws Exception
     */
    public function update(string $table, array $data, array $filters): array
    {
        try {
            $params = [];
            foreach ($filters as $column => $value) {
                if (is_array($value)) {
                    $operator = $value[0];
                    $filterValue = $value[1];
                    $params[$column] = $operator . '.' . $filterValue;
                } else {
                    $params[$column] = 'eq.' . $value;
                }
            }

            $response = $this->restClient->patch($table, [
                'json' => $data,
                'query' => $params,
                'headers' => ['Prefer' => 'return=representation']
            ]);

            return json_decode($response->getBody()->getContents(), true);

        } catch (ClientException $e) {
            $this->handleException($e, 'UPDATE');
        } catch (ServerException $e) {
            $this->handleException($e, 'UPDATE');
        } catch (RequestException $e) {
            $this->handleException($e, 'UPDATE');
        }
    }

    /**
     * Delete data from a table
     * 
     * @param string $table Table name
     * @param array $filters WHERE conditions
     * @return array
     * @throws Exception
     */
    public function delete(string $table, array $filters): array
    {
        try {
            $params = [];
            foreach ($filters as $column => $value) {
                if (is_array($value)) {
                    $operator = $value[0];
                    $filterValue = $value[1];
                    $params[$column] = $operator . '.' . $filterValue;
                } else {
                    $params[$column] = 'eq.' . $value;
                }
            }

            $response = $this->restClient->delete($table, [
                'query' => $params,
                'headers' => ['Prefer' => 'return=representation']
            ]);

            return json_decode($response->getBody()->getContents(), true);

        } catch (ClientException $e) {
            $this->handleException($e, 'DELETE');
        } catch (ServerException $e) {
            $this->handleException($e, 'DELETE');
        } catch (RequestException $e) {
            $this->handleException($e, 'DELETE');
        }
    }

    /**
     * Upload file to Supabase Storage
     * 
     * @param string $bucket Bucket name
     * @param string $path File path in bucket
     * @param mixed $fileContent File content (string or resource)
     * @param array $options Upload options
     * @return array
     * @throws Exception
     */
    public function uploadFile(string $bucket, string $path, $fileContent, array $options = []): array
    {
        try {
            $headers = [];
            
            if (isset($options['content_type'])) {
                $headers['Content-Type'] = $options['content_type'];
            }
            
            if (isset($options['cache_control'])) {
                $headers['Cache-Control'] = $options['cache_control'];
            }

            $upsert = $options['upsert'] ?? false;
            $url = "object/{$bucket}/{$path}";
            
            if ($upsert) {
                $headers['x-upsert'] = 'true';
            }

            $response = $this->storageClient->post($url, [
                'body' => $fileContent,
                'headers' => $headers
            ]);

            return json_decode($response->getBody()->getContents(), true);

        } catch (ClientException $e) {
            $this->handleException($e, 'UPLOAD');
        } catch (ServerException $e) {
            $this->handleException($e, 'UPLOAD');
        } catch (RequestException $e) {
            $this->handleException($e, 'UPLOAD');
        }
    }

    /**
     * Download file from Supabase Storage
     * 
     * @param string $bucket Bucket name
     * @param string $path File path in bucket
     * @return string File content
     * @throws Exception
     */
    public function downloadFile(string $bucket, string $path): string
    {
        try {
            $url = "object/{$bucket}/{$path}";
            $response = $this->storageClient->get($url);
            return $response->getBody()->getContents();

        } catch (ClientException $e) {
            $this->handleException($e, 'DOWNLOAD');
        } catch (ServerException $e) {
            $this->handleException($e, 'DOWNLOAD');
        } catch (RequestException $e) {
            $this->handleException($e, 'DOWNLOAD');
        }
    }

    /**
     * Delete file from Supabase Storage
     * 
     * @param string $bucket Bucket name
     * @param string $path File path in bucket
     * @return array
     * @throws Exception
     */
    public function deleteFile(string $bucket, string $path): array
    {
        try {
            $url = "object/{$bucket}/{$path}";
            $response = $this->storageClient->delete($url);
            return json_decode($response->getBody()->getContents(), true);

        } catch (ClientException $e) {
            $this->handleException($e, 'DELETE_FILE');
        } catch (ServerException $e) {
            $this->handleException($e, 'DELETE_FILE');
        } catch (RequestException $e) {
            $this->handleException($e, 'DELETE_FILE');
        }
    }

    /**
     * List files in a bucket
     * 
     * @param string $bucket Bucket name
     * @param string $path Folder path (optional)
     * @param array $options List options
     * @return array
     * @throws Exception
     */
    public function listFiles(string $bucket, string $path = '', array $options = []): array
    {
        try {
            $url = "object/list/{$bucket}";
            $params = [];
            
            if (!empty($path)) {
                $params['prefix'] = $path;
            }
            
            if (isset($options['limit'])) {
                $params['limit'] = $options['limit'];
            }
            
            if (isset($options['offset'])) {
                $params['offset'] = $options['offset'];
            }

            $response = $this->storageClient->post($url, [
                'json' => $params
            ]);

            return json_decode($response->getBody()->getContents(), true);

        } catch (ClientException $e) {
            $this->handleException($e, 'LIST_FILES');
        } catch (ServerException $e) {
            $this->handleException($e, 'LIST_FILES');
        }
    }

    /**
     * Get public URL for a file
     * 
     * @param string $bucket Bucket name
     * @param string $path File path
     * @return string Public URL
     */
    public function getPublicUrl(string $bucket, string $path): string
    {
        return $this->config['supabase']['url'] . "/storage/v1/object/public/{$bucket}/{$path}";
    }

    /**
     * Get signed URL for a private file
     * 
     * @param string $bucket Bucket name
     * @param string $path File path
     * @param int $expiresIn Expiration time in seconds
     * @return array
     * @throws Exception
     */
    public function getSignedUrl(string $bucket, string $path, int $expiresIn = 3600): array
    {
        try {
            $url = "object/sign/{$bucket}/{$path}";
            $response = $this->storageClient->post($url, [
                'json' => ['expiresIn' => $expiresIn]
            ]);

            $result = json_decode($response->getBody()->getContents(), true);
            
            if (isset($result['signedURL'])) {
                return [
                    'signedURL' => $this->config['supabase']['url'] . $result['signedURL'],
                    'path' => $path
                ];
            }

            return $result;

        } catch (ClientException $e) {
            $this->handleException($e, 'SIGNED_URL');
        } catch (ServerException $e) {
            $this->handleException($e, 'SIGNED_URL');
        } catch (RequestException $e) {
            $this->handleException($e, 'SIGNED_URL');
        }
    }

    /**
     * Handle HTTP exceptions and convert to meaningful errors
     * 
     * @param RequestException $e
     * @param string $operation
     * @throws Exception
     */
    private function handleException(RequestException $e, string $operation): void
    {
        $statusCode = $e->getResponse() ? $e->getResponse()->getStatusCode() : 0;
        $responseBody = $e->getResponse() ? $e->getResponse()->getBody()->getContents() : '';
        
        $errorData = json_decode($responseBody, true);
        $errorMessage = $errorData['message'] ?? $e->getMessage();
        
        error_log("Supabase {$operation} Error ({$statusCode}): " . $responseBody);
        
        throw new Exception("Database {$operation} failed: " . $errorMessage, $statusCode);
    }
}

// Global instance for easy access
function getDatabase(): SupabaseDatabase
{
    static $database = null;
    if ($database === null) {
        $database = new SupabaseDatabase();
    }
    return $database;
}
