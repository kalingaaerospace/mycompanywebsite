-- Verification script to test RLS setup
-- Execute this in Supabase SQL Editor AFTER creating the files table and policies

-- Test 1: Verify table structure
SELECT 
    column_name, 
    data_type, 
    is_nullable, 
    column_default
FROM information_schema.columns 
WHERE table_name = 'files' 
ORDER BY ordinal_position;

-- Test 2: Verify RLS is enabled
SELECT 
    schemaname, 
    tablename, 
    rowsecurity 
FROM pg_tables 
WHERE tablename = 'files';

-- Test 3: List all policies on files table
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'files';

-- Test 4: Verify storage bucket exists
SELECT 
    id,
    name,
    public
FROM storage.buckets 
WHERE id = 'user-files';

-- Test 5: List storage policies
SELECT 
    policyname,
    cmd,
    roles
FROM pg_policies 
WHERE tablename = 'objects' 
AND schemaname = 'storage'
AND policyname LIKE '%user-files%';

-- Test queries (these should return empty results when run without authentication)
-- Uncomment to test (these will fail with RLS enabled and no auth):

/*
-- This should return no rows when not authenticated
SELECT * FROM files;

-- This should fail when not authenticated  
INSERT INTO files (user_id, filename, original_name, file_size, file_type, file_path) 
VALUES (gen_random_uuid(), 'test.txt', 'test.txt', 100, 'text/plain', '/test/test.txt');
*/
